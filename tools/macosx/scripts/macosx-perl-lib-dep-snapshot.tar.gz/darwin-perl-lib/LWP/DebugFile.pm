package LWP::DebugFile;
$LWP::DebugFile::VERSION = '6.27';
# legacy stub

1;
